import time
import os

def title(title_name):
    print(f"---- {title_name} ----")

def section(section_name):
    print(f"--- {section_name} ---\n")

def subsection(subsection_name):
    print(f"-- {subsection_name} --\n")

def short_dash():
    print("\n----------------------------------\n")

def dash():
    print("\n-------------------------------------------------------------------------------------------------------\n")

def formatted_list(list_name):
    return(", ".join(list_name))

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

def user_continue():
    short_dash()
    print("Press Enter to Continue")
    input()
    clear_console()
